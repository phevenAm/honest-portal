import React from 'react';
import './Avatar.scss';

export default function Avatar({ initials, color = 'sage', size = 40 }) {
  return (
    <div aria-hidden="true" className={`avatar avatar--${color}`} style={{ width: size, height: size, fontSize: size * 0.35 }}>
      {initials}
    </div>
  );
}
