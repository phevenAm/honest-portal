import React from 'react';
import './Button.scss';

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  onClick,
  type = 'button',
  fullWidth = false,
  className = '',
  'aria-label': ariaLabel,
  ...props
}) {
  const classes = ['button', `button--${variant}`, `button--${size}`, fullWidth ? 'button--full' : '', className]
    .filter(Boolean)
    .join(' ');

  return (
    <button type={type} onClick={onClick} disabled={disabled} aria-label={ariaLabel} className={classes} {...props}>
      {children}
    </button>
  );
}
