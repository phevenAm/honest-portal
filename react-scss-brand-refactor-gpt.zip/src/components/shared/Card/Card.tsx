import React from 'react';
import './Card.scss';

export default function Card({ children, style, className = '', onClick, ...props }) {
  const classes = ['card', onClick ? 'card--interactive' : '', className].filter(Boolean).join(' ');
  return (
    <div onClick={onClick} role={onClick ? 'button' : undefined} tabIndex={onClick ? 0 : undefined} onKeyDown={onClick ? (e) => e.key === 'Enter' && onClick(e) : undefined} className={classes} style={style} {...props}>
      {children}
    </div>
  );
}
