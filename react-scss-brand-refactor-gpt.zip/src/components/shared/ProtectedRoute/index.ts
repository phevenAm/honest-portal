export { default } from './ProtectedRoute';
