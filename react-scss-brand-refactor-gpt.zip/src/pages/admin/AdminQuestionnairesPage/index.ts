export { default } from './AdminQuestionnairesPage';
