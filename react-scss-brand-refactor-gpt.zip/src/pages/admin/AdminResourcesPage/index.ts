export { default } from './AdminResourcesPage';
