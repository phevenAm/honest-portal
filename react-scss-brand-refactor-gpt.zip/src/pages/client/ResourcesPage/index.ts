export { default } from './ResourcesPage';
