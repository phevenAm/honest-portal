export { default } from './SignUpPage';
