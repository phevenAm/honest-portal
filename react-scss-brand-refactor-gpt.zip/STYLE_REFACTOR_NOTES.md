# Styling refactor notes

- Global SCSS design tokens now live in `src/styles/`.
- `src/index.tsx` imports `src/styles/main.scss` instead of `index.css`.
- Shared components and pages have been moved into same-name folders with a colocated `.scss` file.
- Brand colours have been shifted toward warm cream, sage/olive, and muted clay tones inspired by abidecounselling.uk.
- Text, accent, danger, and muted colours were adjusted to keep stronger contrast in both light and dark mode.
- Emoji usage in React UI was replaced with text/SVG-style treatment where touched.

If your project does not already have Sass installed, run:

```bash
npm install -D sass
```
