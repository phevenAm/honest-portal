import { expect, test } from 'vitest'
import { render, screen } from '@testing-library/react';
import AdminClientsPage from '../AdminClientsPage';

test('renders AdminClientsPage component', () => {
  render(<AdminClientsPage />);
  const headingElement = screen.getByText(/Admin Clients Page/i);
  expect(headingElement).toBeInTheDocument();
});