import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, Link } from 'react-router-dom';
import { signIn, selectIsAuthenticated, selectLoginError, selectIsAdmin, clearError } from '../../../store/slices/authSlice';
import styles from './LoginPage.module.css';

export default function LoginPage() {
  const dispatch        = useDispatch();
  const navigate        = useNavigate();
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const isAdmin         = useSelector(selectIsAdmin);
  const loginError = useSelector(selectLoginError)
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);

  // Redirect if already logged in
  useEffect(() => {
    if (isAuthenticated) {
      navigate(isAdmin ? '/admin' : '/dashboard', { replace: true });
    }
  }, [isAuthenticated, isAdmin, navigate]);

  // Clear error when user starts typing again
  useEffect(() => {
    if (loginError) dispatch(clearError());
  }, [email, password]); // eslint-disable-line

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
dispatch(signIn({ email, password })) .then(result => {
    if (result.success) {
      navigate(result.role === 'admin' ? '/admin' : '/dashboard');
    }
})

    setLoading(false);
  };

  const inputStyle = {
    width: '100%', padding: '10px 13px',
    border: '1.5px solid var(--border)', borderRadius: 12,
    background: 'var(--bg-muted)', color: 'var(--text-primary)',
    fontFamily: 'var(--font-sans)', fontSize: 14,
    outline: 'none', boxSizing: 'border-box',
  }

  return (
    <div className={styles.page}>
      {/* Background blobs */}
      <div className={styles.blobTop} />
      <div className={styles.blobBottom} />

      <div className={styles.container}>
        {/* Logo */}
        <div className={styles.logo}>
          <div className={styles.logoIcon}>🌿</div>
          <h1 className={styles.logoTitle}>WithMe</h1>
          <p className={styles.logoSub}>A safe space for your journey</p>
        </div>

        <div className={styles.card}>
          <h2 className={styles.heading}>Hello!</h2>

          {loginError && (
            <div role="alert" className={styles.error}>
              {loginError}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="email" className={styles.label}>Email address</label>
              <input
                id="email" type="email" required
                value={email} onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                style={inputStyle}
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="password" className={styles.label}>Password</label>
              <input
                id="password" type="password" required
                value={password} onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                style={inputStyle}
              />
            </div>
            <button type="submit" disabled={loading} style={{ width: '100%', padding: 11, background: 'var(--accent)', color: '#fff', border: 'none', borderRadius: 999, fontFamily: 'var(--font-sans)', fontSize: 14, fontWeight: 500, cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? 0.7 : 1 }}>
              {loading ? 'Signing in…' : 'Sign in'}
            </button>
          </form>

          <p style={{ textAlign: 'center', marginTop: 20, fontSize: 13, color: 'var(--text-muted)' }}>
            Don't have an account?{' '}
            <Link to="/signup" style={{ color: 'var(--accent)', fontWeight: 500, textDecoration: 'none' }}>Sign up</Link>
          </p>
        </div>
      </div>
    </div>
  )
}